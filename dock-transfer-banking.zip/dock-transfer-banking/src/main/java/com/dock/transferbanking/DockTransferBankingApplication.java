package com.dock.transferbanking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DockTransferBankingApplication {

	public static void main(String[] args) {
		SpringApplication.run(DockTransferBankingApplication.class, args);
	}

}
